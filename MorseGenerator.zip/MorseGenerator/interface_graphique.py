import tkinter
import tkinter.messagebox
import tkinter.ttk
import fonctions_morse
import gestion_dictionnaire
import threading
import mode_console
import webbrowser


def lancer_documentation_pdf():
    """
    ouvre un document dans le navigateur au format PDF
    """
    webbrowser.open('Morse_Generator_A_Doucet_et_E_Pertegaz.pdf')


def lance_mode_console(fenetre, objet_de_la_fenetre):
    """
    verifie si une emission de signal est en cours et affiche un message si besoin
    sinon il ferme le programme et ouvre le mode console
    Args :
    objet_de_la_fenetre (dict): regroupe tous les éléments de la fenetre
        signal_en_cours_emission (bool): emission en cours
    """
    if (objet_de_la_fenetre["signal_en_cours_emission"] == True):
        tkinter.messagebox.showinfo(
            title="Wait", message="Execution en cours, arreter l'action avant de quitter ", icon='question')
    else:
        fenetre.destroy()
        mode_console.choix_fait_par_utilisateur()


def affiche_image_dans_canvas(objet_de_la_fenetre, image_afficher, lettre_en_cours, numero_image):
    """
    modifie une image dans la fenetre principale
    Args :
    image_afficher (dict): toutes les images de l'interface sont dans ce dictionnaire
    lettre_en_cours: permet d'indexer les images quand plusieurs sont nécéssaires pour afficher un signal
    numero_image (int): numéro de l'image en cours
    objet_de_la_fenetre (dict): regroupe tous les éléments de la fenetre
        repertoire_type_signal (str): emplacement du repertoire du signal correspondant
        image_en_cours_emission (obj): objet de l'image
        canvas(obj): canvas de la fenetre principale 
    """
    image_afficher[lettre_en_cours] = tkinter.PhotoImage(
        file=objet_de_la_fenetre["repertoire_type_signal"] + "/graphique/" + lettre_en_cours)
    objet_de_la_fenetre["canvas"].itemconfigure(
        objet_de_la_fenetre['image_en_cours_emission'+str(numero_image)], image=image_afficher[lettre_en_cours])
    objet_de_la_fenetre["canvas"].image = image_afficher[lettre_en_cours]


def change_image_background(objet_de_la_fenetre):
    """
    modifie le backround de la fenetre principale en fonction du signal selectionné
    Args :
    objet_de_la_fenetre (dict): regroupe tous les éléments de la fenetre
        image_background (obj): image de background de l'interface
        repertoire_type_signal (str): emplacement du repertoire du signal correspondant
        canvas(obj): canvas de la fenetre principale 
    """
    objet_de_la_fenetre["image_background"] = tkinter.PhotoImage(
        file=objet_de_la_fenetre["repertoire_type_signal"]+"/background.gif")
    objet_de_la_fenetre["canvas"].itemconfigure(
        objet_de_la_fenetre["background"], image=objet_de_la_fenetre["image_background"])
    objet_de_la_fenetre["canvas"].image = objet_de_la_fenetre["image_background"]


def fenetre_dev(objet_de_la_fenetre):
    """
    modifie le backround de la fenetre principale en fonction du signal selectionné
    Args :
    objet_de_la_fenetre (dict): regroupe tous les éléments de la fenetre
        image_background (obj): image de background de l'interface
        repertoire_type_signal (str): emplacement du repertoire du signal correspondant
        canvas(obj): canvas de la fenetre principale 
    """
    objet_de_la_fenetre["signal_en_cours_emission"] = False  # arrete l'emission du signal en cours
    tkinter.messagebox.showinfo(
        title="A Propos", message="Programme développé par : \n \n Evan PERTEGAZ 613 \n Antoine DOUCET 610 ", icon='question')


def fermer_fenetre_config(frame):
    """
    ferme la frame configuration
    Args :
    frame(obj) : frame a fermer
    """
    frame.destroy()


def retour_param_initial(objet_fenetre_config):
    """
    remet les valeur du dictionnaire initial (par defaut) dans les champs de la fenetre config
    Args :
    objet_fenetre_config (dict): regroupe tous les éléments de la frame configuration
    """
    dico_affi_initial = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier(
        "./dictionnaire_code_affichage_Initial.csv")
    objet_fenetre_config['ChampsEspace'].delete(0, 'end')
    objet_fenetre_config['champs_bip_cours'].delete(0, 'end')
    objet_fenetre_config['champs_bip_long'].delete(0, 'end')
    objet_fenetre_config['champs_espace_lettre'].delete(0, 'end')

    objet_fenetre_config['ChampsEspace'].insert(0, dico_affi_initial["/"])
    objet_fenetre_config['champs_bip_cours'].insert(0, dico_affi_initial["o"])
    objet_fenetre_config['champs_bip_long'].insert(0, dico_affi_initial["-"])
    objet_fenetre_config['champs_espace_lettre'].insert(
        0, dico_affi_initial["*"])


def sauvegarder_fenetre_config(objet_fenetre_config):
    """
    sauvegarde dans le fichier  dictionnaire_code_affichage.csv le dictionnaire modifier dans la fenetre config
    Args :
    objet_fenetre_config (dict): regroupe tous les éléments de la frame configuration
    """
    champs_espace = objet_fenetre_config["ChampsEspace"].get()
    champs_bip_cours = objet_fenetre_config["champs_bip_cours"].get()
    champs_bip_long = objet_fenetre_config["champs_bip_long"].get()
    champs_espace_lettre = objet_fenetre_config["champs_espace_lettre"].get()

    if (fonctions_morse.met_a_jour_dictionnaire_affichage(champs_espace, champs_bip_cours, champs_bip_long, champs_espace_lettre) == True):
        tkinter.messagebox.showinfo(
            title="Sauvegarde OK", message="Sauvegarde éffectué avec succès")
    else:
        tkinter.messagebox.showinfo(
            title="ERROR", message="Erreur Nombre de caractères")


def configuration_graphique(fenetre, objet_de_la_fenetre):
    """
    Affiche dans la fenetre une autre frame configuration par dessus l'autre frame
    elle sers de fonction principale pour toute la partie configuration
    Args :
    fenetre (obj): fenetre principale
    objet_de_la_fenetre (dict): regroupe tous les éléments de la frame
    """
    objet_de_la_fenetre["signal_en_cours_emission"] = False

    dico_affi = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier(
        "./dictionnaire_code_affichage.csv")
    objet_fenetre_config = {}

    frmConfig = tkinter.Frame(fenetre, bg='grey')
    # Emplacement du frame
    frmConfig.place(x=10, y=10, width=780, height=580)

    label2 = tkinter.Label(
        frmConfig, text="CONFIGURATION:", font=("Helvetica", 40))
    label2.place(x=20, y=10, width=500, height=50)

    label2 = tkinter.Label(frmConfig, text="espace",
                           font=("Helvetica", 10))  # /
    label2.place(x=100, y=250, width=200, height=30)
    # code affichage
    objet_fenetre_config['ChampsEspace'] = tkinter.Entry(
        frmConfig, font=("Helvetica", 10))
    objet_fenetre_config['ChampsEspace'].place(
        x=340, y=250, width=100, height=30)
    objet_fenetre_config['ChampsEspace'].insert(0, dico_affi["/"])

    label2 = tkinter.Label(frmConfig, text="bip cours",
                           font=("Helvetica", 10))  # o
    label2.place(x=100, y=300, width=200, height=30)
    # code affichage
    objet_fenetre_config['champs_bip_cours'] = tkinter.Entry(
        frmConfig, font=("Helvetica", 10))
    objet_fenetre_config['champs_bip_cours'].place(
        x=340, y=300, width=100, height=30)
    objet_fenetre_config['champs_bip_cours'].insert(0, dico_affi["o"])

    label2 = tkinter.Label(frmConfig, text="bip long",
                           font=("Helvetica", 10))  # -
    label2.place(x=100, y=350, width=200, height=30)
    # code affichage
    objet_fenetre_config['champs_bip_long'] = tkinter.Entry(
        frmConfig, font=("Helvetica", 10))
    objet_fenetre_config['champs_bip_long'].place(
        x=340, y=350, width=100, height=30)
    objet_fenetre_config['champs_bip_long'].insert(0, dico_affi["-"])

    label2 = tkinter.Label(
        frmConfig, text="espace entre les lettres", font=("Helvetica", 10))  # *
    label2.place(x=100, y=400, width=200, height=30)
    # code affichage
    objet_fenetre_config['champs_espace_lettre'] = tkinter.Entry(
        frmConfig, font=("Helvetica", 10))
    objet_fenetre_config['champs_espace_lettre'].place(
        x=340, y=400, width=100, height=30)
    objet_fenetre_config['champs_espace_lettre'].insert(0, dico_affi["*"])

    # Création d'un bouton au sein du frame
    bouton_quitter = tkinter.Button(frmConfig, text="Retour config d'origine", bg='red',
                                    fg='white', command=lambda: retour_param_initial(objet_fenetre_config))
    bouton_quitter.place(x=300, y=520, width=200, height=30)
    bouton_quitter = tkinter.Button(frmConfig, text="Quitter", bg='red',
                                    fg='white', command=lambda: fermer_fenetre_config(frmConfig))
    bouton_quitter.place(x=650, y=520, width=100, height=30)
    bouton_sauvegarder = tkinter.Button(frmConfig, text="Sauvegarder", bg='green',
                                        fg='white', command=lambda: sauvegarder_fenetre_config(objet_fenetre_config))
    bouton_sauvegarder.place(x=530, y=520, width=100, height=30)


def fonction_quitter_le_programme(fenetre, objet_de_la_fenetre):
    """
    Refuse de quitter si un signal est en cours.
    sinon il ferme le programme 
    Args :
    fenetre (obj): fenetre principale
    objet_de_la_fenetre (dict): regroupe tous les éléments de la frame
    """
    if (objet_de_la_fenetre["signal_en_cours_emission"] == True):
        tkinter.messagebox.showinfo(
            title="Wait", message="Execution en cours, arreter l'action avant de quitter ", icon='question')
    elif (tkinter.messagebox.askquestion("Voulez vous nous quitter?", "Exit? Tchao ? bye bye ? ") == "yes"):
        objet_de_la_fenetre["signal_en_cours_emission"] = False
        fenetre.destroy()


def choix_type_signal(objet_de_la_fenetre):
    """
    permet de choisir le signal
    ne peux être executé que si aucun signal n'est en cours 
    Args :
    objet_de_la_fenetre (dict): regroupe tous les éléments de la frame
        signal_en_cours_emission (bool): emission d'un signal en cours
    """
    if (objet_de_la_fenetre["signal_en_cours_emission"] == True):
        tkinter.messagebox.showinfo(
            title="Wait", message="Execution en cours, arreter l'action avant de quitter ", icon='question')
    else:
        objet_de_la_fenetre["repertoire_type_signal"] = "./" + \
            objet_de_la_fenetre["listeCombo"].get()
        objet_de_la_fenetre["text_titre"].set(
            "Signal: " + objet_de_la_fenetre["listeCombo"].get())
        change_image_background(objet_de_la_fenetre)


def transmettre_le_message(choix, objet_de_la_fenetre):
    """
    Transforme le message saisis suivant le bouton choisis en message encode avant de le dispatcher sous toute les formes
    Args :
    objet_de_la_fenetre (dict): regroupe tous les éléments de la frame
    signal_en_cours_emission (bool): emission d'un signal en cours
    """
    dico_code = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier(
        objet_de_la_fenetre["repertoire_type_signal"] + "/dictionnaire_lettre_code.csv")
    dico_affi = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier(
        "./dictionnaire_code_affichage.csv")
    dico_sono = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier(
        objet_de_la_fenetre["repertoire_type_signal"] + "/dictionnaire_code_signal.csv")

    if (choix == "bouton_stop_emission"):  # cette fonction stop l'envoi du signal en cours
        objet_de_la_fenetre["signal_en_cours_emission"] = False
        return True

    # si message ne cours, on affiche une erreur et on quitte la fonction
    if (objet_de_la_fenetre["signal_en_cours_emission"]):
        tkinter.messagebox.showinfo(
            title="ERROR", message="Message déja en cours d'émission")
        return False

    # le choix 1 est quand on à rentrer un message a emettre
    if (choix == "bouton_message_a_transmettre"):
        message = objet_de_la_fenetre["message_a_transmettre"].get().upper()

        if (message == ""):
            tkinter.messagebox.showinfo(title="ERROR", message="Message vide")
            return False

        if (fonctions_morse.message_soit_valide(message, dico_code)):
            message_code = fonctions_morse.encoder_le_message(
                message, dico_code)
        else:
            tkinter.messagebox.showinfo(
                title="ERROR", message="Message non valide")
            return False

    # le choix 2 est quand on à rentrer un message codé
    if (choix == "boutton_message_afficher"):
        message = objet_de_la_fenetre["message_afficher"].get()
        if (message == ""):
            tkinter.messagebox.showinfo(title="ERROR", message="Message vide")
            return False

        if (fonctions_morse.message_soit_valide(fonctions_morse.decoder_le_message(message, dico_affi), dico_sono)):
            message_code = fonctions_morse.decoder_le_message(
                message, dico_affi)
        else:
            tkinter.messagebox.showinfo(
                title="ERROR", message="Message non valide \n Verifier votre Fichier de configuration")
            return False

    # le choix 3 est quand on à rentrer un message émis
    if (choix == "boutton_message_emis"):
        message = objet_de_la_fenetre["message_emis"].get()
        if (message == ""):
            tkinter.messagebox.showinfo(title="ERROR", message="Message vide")
            return False
        if (fonctions_morse.message_soit_valide(message, fonctions_morse.inverser_dictionnaire(dico_sono))):
            message_code = fonctions_morse.decoder_le_message(
                message, dico_sono)
        else:
            tkinter.messagebox.showinfo(
                title="ERROR", message="Message non valide")
            return False

    objet_de_la_fenetre["message_a_transmettre"].delete(0, 'end')
    objet_de_la_fenetre["message_a_transmettre"].insert(
        0, fonctions_morse.decoder_le_message(message_code, dico_code))
    objet_de_la_fenetre["message_afficher"].delete(0, 'end')
    objet_de_la_fenetre["message_afficher"].insert(
        0, fonctions_morse.encoder_le_message(message_code, dico_affi))
    objet_de_la_fenetre["message_emis"].delete(0, 'end')
    objet_de_la_fenetre["message_emis"].insert(
        0, fonctions_morse.encoder_le_message(message_code, dico_sono))

    objet_de_la_fenetre["signal_en_cours_emission"] = True
    objet_de_la_fenetre["message_a_jouer"] = fonctions_morse.encoder_le_message(
        message_code, dico_sono)
    # pour eviter de bloquer tout le programme, lancement de cette fonction dans un thread a part
    thread = threading.Thread(target=fonctions_morse.emettre_le_signal, args=(
        objet_de_la_fenetre, "mode_graphique"))
    thread.start()
    return True


def fenetre_principal():
    """
    ceci est la premiere fonction du programme graphique, elle initialise la fenetre tkinter,
    crée objet_de_la_fenetre qui regroupe tous les elements et appel les fonctions de bases
    Args : aucun
    """
    # ce dictionaire stock tous les elements présent dans la fenetre ainsi que des variables importantes
    objet_de_la_fenetre = {} # type: dict
    # création de ma fenetres
    fenetre = tkinter.Tk()
    fenetre.protocol("WM_DELETE_WINDOW", lambda: fonction_quitter_le_programme(
        fenetre, objet_de_la_fenetre))
    fenetre.wm_attributes('-topmost', 1)
    fenetre.geometry("800x600")
    fenetre.resizable(height = False, width = False)
    fenetre.title("Morse Generator V2")

    # si l'entrée "signal_en_cours_emission" n'existe pas c'est qu'il n'y en as pas en cours
    # cette fonction permet de savoir si un signal est en cours, si on le passe a False alors qu'un signal est en cours alors il se termine
    if not "signal_en_cours_emission" in objet_de_la_fenetre:
        objet_de_la_fenetre["signal_en_cours_emission"] = False

    # Chargement du reperoitre par defaut utilisé pour les annuaires + fichiers (par defaut du mode  Morse_sonore)
    objet_de_la_fenetre["repertoire_type_signal"] = "./Morse_sonore"

    objet_de_la_fenetre["canvas"] = tkinter.Canvas(
        fenetre, width=800, height=600)
    objet_de_la_fenetre["canvas"].pack()

    objet_de_la_fenetre["image_background"] = tkinter.PhotoImage(
        file="./vide.gif")
    objet_de_la_fenetre['background'] = objet_de_la_fenetre["canvas"].create_image(
        400, 300, image=objet_de_la_fenetre["image_background"])

    # menu déroulant
    listeProduits = fonctions_morse.recup_list_repertoires()
    objet_de_la_fenetre["listeCombo"] = tkinter.ttk.Combobox(
        objet_de_la_fenetre["canvas"], values=listeProduits, state='readonly', font=("Helvetica", 10))
    objet_de_la_fenetre["listeCombo"].place(x=100, y=100, width=200, height=30)
    bouton_changer_type_signal = tkinter.Button(
        objet_de_la_fenetre["canvas"], text="charger", bg='blue', fg='white', command=lambda: choix_type_signal(objet_de_la_fenetre))
    bouton_changer_type_signal.place(x=350, y=100, width=100, height=30)

    # création du menu
    menu_principal = tkinter.Menu(fenetre)

    premier_menu = tkinter.Menu(menu_principal, tearoff=0)
    premier_menu.add_command(label="Configuration", command=lambda: configuration_graphique(
        fenetre, objet_de_la_fenetre))
    premier_menu.add_separator()
    premier_menu.add_command(label="Quitter", command=lambda: fonction_quitter_le_programme(
        fenetre, objet_de_la_fenetre))

    deuxieme_menu = tkinter.Menu(menu_principal, tearoff=0)
    deuxieme_menu.add_command(label="Documentation",
                              command=lancer_documentation_pdf) #Si ce n est pas une lambda le pdf ce lancera pas au bon moment
    deuxieme_menu.add_separator()
    deuxieme_menu.add_command(
        label="À propos", command=lambda: fenetre_dev(objet_de_la_fenetre))

    menu_principal.add_cascade(label="Fichier", menu=premier_menu)
    menu_principal.add_cascade(label="Aide", menu=deuxieme_menu)
    menu_principal.add_cascade(label="Mode Console", command=lambda: lance_mode_console(
        fenetre, objet_de_la_fenetre))

    objet_de_la_fenetre["text_titre"] = tkinter.StringVar()

    # label du mode choisit
    label_titre = tkinter.Label(fenetre, textvariable=objet_de_la_fenetre["text_titre"], font=(
        "Helvetica", 20), bg='lightgray')
    label_titre.place(x=20, y=10, width=600, height=50)

    label = tkinter.Label(fenetre, text="Entrer le message à transmettre : ", font=(
        "Helvetica", 12), bg='lightgray')  # *
    label.place(x=50, y=200, width=250, height=20)

    objet_de_la_fenetre["message_a_transmettre"] = tkinter.Entry(
        fenetre, font=("Helvetica", 10))
    objet_de_la_fenetre["message_a_transmettre"].place(
        x=350, y=200, width=325, height=30)

    bouton_GO_transmettre = tkinter.Button(fenetre, text="GO", bg='green', fg='white', command=lambda: transmettre_le_message(
        "bouton_message_a_transmettre", objet_de_la_fenetre))
    bouton_GO_transmettre.place(x=700, y=200, width=60, height=30)

    label = tkinter.Label(fenetre, text="Message encodé : ", font=(
        "Helvetica", 12), bg='lightgray')  # *
    label.place(x=50, y=250, width=250, height=20)

    objet_de_la_fenetre["message_afficher"] = tkinter.Entry(
        fenetre, font=("Helvetica", 10))
    objet_de_la_fenetre["message_afficher"].place(
        x=350, y=250, width=325, height=30)

    bouton_GO_transmettre = tkinter.Button(fenetre, text="GO", bg='green', fg='white', command=lambda: transmettre_le_message(
        "boutton_message_afficher", objet_de_la_fenetre))
    bouton_GO_transmettre.place(x=700, y=250, width=60, height=30)

    label = tkinter.Label(fenetre, text="Message émis: ",
                          font=("Helvetica", 12), bg='lightgray')  # *
    label.place(x=50, y=300, width=250, height=20)

    objet_de_la_fenetre["message_emis"] = tkinter.Entry(
        fenetre, font=("Helvetica", 10))
    objet_de_la_fenetre["message_emis"].place(
        x=100, y=325, width=575, height=30)

    bouton_GO_transmettre = tkinter.Button(fenetre, text="GO", bg='green', fg='white',
                                           command=lambda: transmettre_le_message("boutton_message_emis", objet_de_la_fenetre))
    bouton_GO_transmettre.place(x=700, y=315, width=60, height=30)

    bouton_GO_transmettre = tkinter.Button(fenetre, text="STOP EMISSION", bg='red', fg='white',
                                           command=lambda: transmettre_le_message("bouton_stop_emission", objet_de_la_fenetre))
    bouton_GO_transmettre.place(x=550, y=375, width=150, height=30)

    img = tkinter.PhotoImage(file="./vide.gif")
    objet_de_la_fenetre['image_en_cours_emission0'] = objet_de_la_fenetre["canvas"].create_image(
        295, 450, image=img)
    objet_de_la_fenetre['image_en_cours_emission1'] = objet_de_la_fenetre["canvas"].create_image(
        300, 450, image=img)
    objet_de_la_fenetre['image_en_cours_emission2'] = objet_de_la_fenetre["canvas"].create_image(
        305, 450, image=img)

    objet_de_la_fenetre["message_a_transmettre"].insert(0, "Hello world")

    # PERMET de charger le signal en cours
    objet_de_la_fenetre["listeCombo"].current(2)
    choix_type_signal(objet_de_la_fenetre)

    # boucle principale
    fenetre.config(menu=menu_principal)
    fenetre.mainloop()
