import csv

def recupere_dictionnaire_depuis_fichier(nom_du_fichier): 
    """ Lit le fichier et le renvoie sous forme de liste de dictionnaires.
    Argument:
    nom_du_fichier(str): le nom du fichier à lire
    Retourne: 
    dico lu dans le fichier"""
    
    assert type(nom_du_fichier) is str #vérifie que le chemin du fichier est un str

    dictionnaire={} #créer un dictionnaire à retourner à la fin
    with open(nom_du_fichier, 'r', encoding='utf-8', newline='') as fichier: #ouverture du fichier
        lecture = csv.DictReader(fichier, delimiter=';') #va lire les informations du fichier
        for row in lecture: #lit toutes les lignes dans le fichier traité au-dessus
            dictionnaire[row["index"]]=row["valeur"]
        return dictionnaire

def modifier_dictionnaire(liste_dictionnaires, valeur_a_modifier):
    """ Modifie la liste de dictionnaires avec les nouvelles valeurs.
    Arguments:
    liste_dictionnaires(dict): liste de dictionnaires a modifier
    valeur_a_modifier(dict): la nouvelle valeur a attribuer
    Retourne:
    liste_dictionnaires (list) : liste de dictionnaire
    """
    
    assert type(liste_dictionnaires) is dict #vérifie que la variable est une liste
    assert type(valeur_a_modifier) is dict #vérifie que la variable est un dictionnaire
    liste_dictionnaires.update(valeur_a_modifier)
    return liste_dictionnaires
    
def enregistre_dictionnaire_dans_fichier(nom_du_fichier, liste_dictionnaires):   
    """ Sauvegarde la modification du dictionnaire dans le fichier.
    Arguments:
    nom_du_fichier(str): nom du fichier à modifier
    liste_dictionnaires(list): liste de dictionnaires modifiée précédemment
    Retourne:
    vrai ou faux"""
    assert type(nom_du_fichier) is str #vérifie que le chemin du fichier est un str
    assert type(liste_dictionnaires) is dict #vérifie que la variable est une liste
    
    with open(nom_du_fichier, 'w', encoding='utf-8', newline='') as fichier: #ouverture du fichier
        writer = csv.DictWriter(fichier, delimiter=';',fieldnames= ['index', 'valeur'])
        writer.writeheader()
        for idx, val in liste_dictionnaires.items():
            writer.writerow({'index': idx , 'valeur': val})
           
if __name__=="__main__":
    assert modifier_dictionnaire({1:2,2:3}, {1:4}) == {1:4,2:3}