# -*- coding: utf-8 -*-
__author__ = "two developers" 
__authors__ = ["Antoine DOUCET", "EVAN PERTEGAZ"]
__copyright__ = "Copyright $YEAR, $COMPANY_NAME"
__credits__ = ["Antoine DOUCET", "EVAN PERTEGAZ",] 
__date__ = "2023/03/30" 
__email__ =  "morse.generator.antoine.evan@gmail.com"
__license__ = "CC-by-nc-nd"
__maintainer__ = "developer" 
__status__ = "Production" 
__version__ = "2.0.0"

import interface_graphique
import mode_console
import tkinter.messagebox



if __name__ == "__main__":
    if tkinter.messagebox.askquestion(title="Démarrage",message="Voulez vous démarrer en mode graphique ? ") == "yes":
        interface_graphique.fenetre_principal()
    else:
        mode_console.choix_fait_par_utilisateur()