import os
import time
import gestion_dictionnaire
import interface_graphique
import playsound

def inverser_dictionnaire(dictionnaire):
    """ 
    renvoi un dictionnaire inversé ou les clefs deviennent des valeurs et des valeurs des clefs
    Argument:
    dictionnaire(dict): dictionnaire     
    Retourne:
    dico_inverse (dict): dicctionnaire inverse
    """
    dico_inverse = {}
    for key , values in dictionnaire.items():
        dico = {values:key}
        dico_inverse.update(dico)
    return dico_inverse

def recup_list_repertoires():
    """
    Liste les répertoires contenant les différent signaux possible.
    Retourne :
    liste_repertoires (list) : liste des répertoires contenant les signaux
    """
    liste_repertoires = []
    rootdir = os.getcwd()
    for file in os.listdir(rootdir):
        dossier = os.path.join(rootdir, file)
        if os.path.isdir(dossier):
            if file[0] != '_':
                liste_repertoires.append(file)
    return liste_repertoires

def message_soit_valide(message,dictionnaire):
    """ Vérifie que le message contient uniquement des caractères autorisés (lettre présente dans le dictionnaire).
    Argument:
    message(str): message entré par l'utilisateur    
    """
    for i in range(0,len(message)):
        if not (message[i] in dictionnaire):
            return False
    return True

def encoder_le_message(message,dictionnaire):
    """
    Permet d'encoder le message 
    Args:
    message(str): message à encoder
    dictionnaire(dict): dictionnaire de d'encodage
    """
    message_code = ""
    for i in range(0,len(message)):
        if (message[i] in dictionnaire):
            message_code = message_code + dictionnaire[message[i]] 
            if (i < len(message)-1):
                message_code = message_code +  dictionnaire["inter_lettre"]
        elif (message[i] == " "):
            message_code = message_code + dictionnaire["espace"] + dictionnaire["inter_lettre"] 
        else:
            message_code = message_code + message[i]
    return message_code

def decoder_le_message(message,dictionnaire):
    """
    Permet de décoder le message encodé
    Args:
    message(str): message a décoder
    dictionnaire(dict): dictionnaire de décodage
    """
    message_code =""
    dico_inverse=inverser_dictionnaire(dictionnaire)
    #inverse le dico
    if (dictionnaire["inter_lettre"] != ""):
        message_en_liste= message.split(dictionnaire["inter_lettre"])
    else:
        message_en_liste=message.strip()
    NbInterlettre=0
    for lettre in message_en_liste:
        if (lettre == ""):
            NbInterlettre = NbInterlettre + 1
        elif(NbInterlettre == 2): #veux dire que c'est un espace entre 2 lettres
            message_code = message_code + "*"
            NbInterlettre = 0
        elif(NbInterlettre >= 2): #veux dire que c'est un espace entre 2 mots
            message_code = message_code + "*/*"
            NbInterlettre = 0
        if (lettre in dico_inverse):
            message_code = message_code +  dico_inverse[lettre]
        elif (lettre != ""):
            message_code = message_code +  lettre

    return message_code

def met_a_jour_dictionnaire_affichage(champs_espace,champs_bip_cours,champs_bip_long,champs_espace_lettre):
    """ 
    Permet de mettre a jour le dictionnaire d'affichage (la configuration)
    Args:
    champs_espace(str) : configuration de l espace 
    champs_bip_cours(str) : configuration du bip court 
    champs_bip_long(str) : configuration du bip long
    champs_espace_lettre(str) : configuration de l espace entre les lettres
    """

    dico_affi = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier("./dictionnaire_code_affichage.csv")
    if champs_espace == "":
        champs_espace = dico_affi["/"]
    if champs_bip_cours == "":
        champs_bip_cours = dico_affi["o"]
    if champs_bip_long == "":
        champs_bip_long = dico_affi["-"]
    if champs_espace_lettre == "":
        champs_espace_lettre = dico_affi["*"]
    if len(champs_espace) == 1 and len(champs_bip_cours) == 1 and len(champs_bip_long) == 1 and len(champs_espace_lettre) == 1 :
        dico_affi["/"] =  champs_espace           
        dico_affi["o"] =  champs_bip_cours   
        dico_affi["-"] =  champs_bip_long   
        dico_affi["*"] =  champs_espace_lettre   
        gestion_dictionnaire.enregistre_dictionnaire_dans_fichier( "./dictionnaire_code_affichage.csv", dico_affi)
        return True
    else :
        return False


def emettre_le_signal(objet_de_la_fenetre,modeEnCours):
    """ 
    Emet le signal voulu
    Args:
    objet_de_la_fenetre(dict) : objet qui contient la situation du dictionnaire, du signal_en_cours_emission et du nb_images_par_signal
    modeEnCours(str) : mode qui est actuellement utilisé 
    """
    message_sonore=objet_de_la_fenetre["message_a_jouer"]
    if (modeEnCours == "mode_graphique"):
        dico_signal = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier( objet_de_la_fenetre["repertoire_type_signal"] + "/dictionnaire_emettre_signal_graphique.csv")
    else:
        dico_signal = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier( objet_de_la_fenetre["repertoire_type_signal"] + "/dictionnaire_emettre_signal_console.csv")
    message_morse_a_afficher = ""

    if (dico_signal["type_emission"] == "son"):
        for i in range(0,len(message_sonore)):
            if objet_de_la_fenetre["signal_en_cours_emission"] == False:
                break
            if (modeEnCours != "mode_graphique"):
                message_morse_a_afficher = message_morse_a_afficher + message_sonore[i]
                print("Signal:  " + message_morse_a_afficher, end='\r')
            playsound.playsound( objet_de_la_fenetre["repertoire_type_signal"] + "/son/" + dico_signal[message_sonore[i]])
        objet_de_la_fenetre["signal_en_cours_emission"] = False
    else:
        nb_images_par_signal = dico_signal["nb_images_par_signal"]
        numero_image = 0
        image_afficher = {} # type: dict
        for i in range(0,len(message_sonore)):
            if objet_de_la_fenetre["signal_en_cours_emission"] == False:
                break
            #affiche la nouvelle image
            if (dico_signal[message_sonore[i]] != "IGNORE"):
                #boucle en fonction du numero_image pour les afficher les une à coté des autres
                if (modeEnCours == "mode_graphique"):
                    interface_graphique.affiche_image_dans_canvas(objet_de_la_fenetre,image_afficher,dico_signal[message_sonore[i]],numero_image)
                else:
                    message_morse_a_afficher = message_morse_a_afficher + dico_signal[message_sonore[i]]
                    print("Signal:  " + message_morse_a_afficher, end='\r')
                numero_image = numero_image +1
                if (str(numero_image) == nb_images_par_signal):
                    numero_image = 0
                    message_morse_a_afficher = message_morse_a_afficher + " "
                    time.sleep(0.5)
        if (objet_de_la_fenetre["signal_en_cours_emission"] != False):
            time.sleep(1)     
        if (modeEnCours == "mode_graphique"):                             
            for i in range(0,int(nb_images_par_signal)):
                interface_graphique.affiche_image_dans_canvas(objet_de_la_fenetre,image_afficher,"vide.gif",numero_image)
                #efface les images en mode graphique
            objet_de_la_fenetre["signal_en_cours_emission"] = False



if __name__ == "__main__":
    assert inverser_dictionnaire({1:2,2:3}) == {2:1,3:2}
    assert message_soit_valide("NSI",{"N":1,"S":2,"I":3}) == True
    assert encoder_le_message("NSI",{"N":"1","S":"2","I":"3","inter_lettre":""}) == "123"
    assert decoder_le_message("123",{"N":"1","S":"2","I":"3","inter_lettre":""})== "NSI"
    