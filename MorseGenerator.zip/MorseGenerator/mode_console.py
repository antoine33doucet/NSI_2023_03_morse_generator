import gestion_dictionnaire
import fonctions_morse
import interface_graphique
import time

def affichage_du_menu(signal,config):
    """
    Affiche le menu principal de la console
    Args :
    signal (str): le signal choisi
    config (str): info si la config a ete modifie
    """
    print(f"""
        ########################## GENERATEUR MORSE ##############
        1) Changer le signal : {signal}
        2) Configuration {config}
                                       ___   _   6) Mode graphique
        3) Message a emettre          [(_)] |=|
        4) Message code               --- o |_|
        5) Message emis                                 7) Quitter
        ##########################################################
        """)

def choix_fait_par_utilisateur():
    """
    Demande a l'utilisateur le choix qu il a fait
    """
    signal = "Morse_sonore" 
    config = ""
    quitter = ""
    while quitter != "stop":
        repertoire_type_signal =    "./" + signal
        dico_code = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier(repertoire_type_signal + "/dictionnaire_lettre_code.csv")
        dico_affi = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier("./dictionnaire_code_affichage.csv")
        dico_sono = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier(repertoire_type_signal + "/dictionnaire_code_signal.csv")

        affichage_du_menu(signal,config)
        choix = input("Marquez le chiffre que vous souhaitez : ")
        if choix == "1":
            signal = changer_signal()
        elif choix == "2":
            config = configuration_du_dictionnaire_affichage()
        elif choix == "3":
            message_encoder = affiche_encode(dico_code,dico_affi)
            son_a_jouer(dico_sono,message_encoder,repertoire_type_signal)
        elif choix == "4":
            message_encoder = entre_message_code(dico_affi,dico_code,dico_sono)
            son_a_jouer(dico_sono,message_encoder,repertoire_type_signal)
        elif choix == "5":
            message_encoder = message_emis(dico_affi,dico_sono)
            son_a_jouer(dico_sono,message_encoder,repertoire_type_signal)
        elif choix == "6":
            quitter = "stop"
            interface_graphique.fenetre_principal()
        elif choix == "7":
            quitter = "stop"

def message_emis(dico_affi,dico_sono):
    """
    Affiche le menu principal de la console
    Args :
    dico_affi (dict): dictionnaire entre le message encode et le message affiche
    dico_sono (dict): dictionnaire entre le message encode et le message à emettre
    Retourne :
    message_code_sono (str) : messsage affiché
    
    """
    Message_a_decoder = "None"
    while fonctions_morse.message_soit_valide(Message_a_decoder,fonctions_morse.inverser_dictionnaire(dico_sono)) == False :
        Message_a_decoder = input("Entrer le message à transmettre : ")
    message_code_sono = fonctions_morse.decoder_le_message(Message_a_decoder,dico_sono)

    print("Message encodé : " + message_code_sono)
    print("Message émis : "+ fonctions_morse.decoder_le_message(message_code_sono,dico_affi))
    return message_code_sono

def entre_message_code(dico_affi,dico_code,dico_sono):
    """
     Demande un message code et le transforme en message_encode (message_de_base).
     Args :
     dico_affi (dict): dictionnaire entre le message encode et le message affiche
     dico_code (dict): dictionnaire entre le message saisi et le message encode
     Retourne :
     message_code (str) : message affiché
    """
    Message_a_decoder = "None"
    while fonctions_morse.message_soit_valide(fonctions_morse.decoder_le_message(Message_a_decoder,dico_affi),dico_sono) == False :
        Message_a_decoder = input("Entrer le message à transmettre : ")
    message_code = fonctions_morse.decoder_le_message(Message_a_decoder,dico_affi)
    print("Message émis : "+ fonctions_morse.decoder_le_message(message_code,dico_code))
    return message_code

def changer_signal():
    """
    Fait choisir l'utilisateur sur un signal parmis ceux proposés.
    Retourne :
    choix_signal(str) : signal choisi
    """
    message_juste = False
    choix_nombre_signal_int = -1
    list_repertoires = fonctions_morse.recup_list_repertoires()
    print("Veuillez choisir le numéro du signal voulu :")
    for i in range (0,len(list_repertoires)):
        print(str(i+1) +" "+str(list_repertoires[i]))
    while message_juste == False : 
        choix_nombre_signal = input("Votre choix : ")
        if (choix_nombre_signal.isdigit()):
            choix_nombre_signal_int = int(choix_nombre_signal)   
            if choix_nombre_signal_int > 0 and choix_nombre_signal_int < (len(list_repertoires)+1) : 
                message_juste = True
    choix_signal = list_repertoires[choix_nombre_signal_int -1 ]
    return choix_signal
   
def son_a_jouer(dico_sono,message_encoder,repertoire_type_signal):
    """
    Joue le signal que l'utilisateur a choisi
    Args :
    dico_sono (dict): dictionnaire entre le message encode et le message à emettre
    message_encoder (str): Message encodé avec le signal souhaite
    repertoire_type_signal (str): Lien vers le répertoire du signal
    """
    objet_du_programme = {}
    objet_du_programme["repertoire_type_signal"] = repertoire_type_signal
    objet_du_programme["message_a_jouer"] = fonctions_morse.encoder_le_message(message_encoder,dico_sono)
    objet_du_programme["signal_en_cours_emission"] = True
    fonctions_morse.emettre_le_signal(objet_du_programme,"mode_console")
    time.sleep(1)

def affiche_encode(dico_code,dico_affi):
    """
     Demande un message et le transforme en message_encode (message_de_base).
     Args :
     dico_affi (dict): dictionnaire entre le message encode et le message affiche
     dico_code (dict): dictionnaire entre le message saisi et le message encode
     Retourne :
     message_encoder(str) : le message encodé
    """
    Message_saisis = "*/*"
    while fonctions_morse.message_soit_valide(Message_saisis,dico_code) == False :
        Message_saisis = input("Entrer le message à transmettre : ")
        Message_saisis = Message_saisis.upper()
        message_encoder = fonctions_morse.encoder_le_message(Message_saisis,dico_code)
        print("Message encodé : " + fonctions_morse.encoder_le_message(message_encoder,dico_affi) )
        print("Message émis : "+ Message_saisis)
        return message_encoder

def configuration_du_dictionnaire_affichage():
    """
    Permet de modifier les valeurs du dictionnaire d'affichage
    Retourne :
    ": Default" ou ": Modifier"(str) : Savoir si le dictionnaire a été modifié.

    """
    reponse_valeur_par_default = ""
    reponse = False
    dico_affi = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier("./dictionnaire_code_affichage.csv")
    print("Espace Configuration :")
    print("Laissez vide pour garder la valeur utilisée")
    while (reponse_valeur_par_default != "O" and reponse_valeur_par_default != "N")  : 
        reponse_valeur_par_default = input("Voulez vous remettre les valeurs par défault (O/N) ? ")
    if reponse_valeur_par_default == "O":
        dico_affi_initial = gestion_dictionnaire.recupere_dictionnaire_depuis_fichier("./dictionnaire_code_affichage_Initial.csv")
        gestion_dictionnaire.enregistre_dictionnaire_dans_fichier( "./dictionnaire_code_affichage.csv", dico_affi_initial)
        print("Configuration enregistrée dans le dictionnaire")
        return ": Default"
    else:
        while reponse != True:
            champs_espace = input("espace (valeur utilisée : " + str(dico_affi["/"]) + ") : ")
            champs_bip_cours = input("bip_cours (valeur utilisée : " + str(dico_affi["o"]) + ") : ")
            champs_bip_long = input("bip_long (valeur utilisée : " + str(dico_affi["-"]) + ") :")
            champs_espace_lettre = input("espace_lettre (valeur utilisée : " + str(dico_affi["*"]) + ") : ")
            
            reponse = fonctions_morse.met_a_jour_dictionnaire_affichage(champs_espace,champs_bip_cours,champs_bip_long,champs_espace_lettre)
            if (reponse == False):
                print("\033[31mErreur: nombre de caractère non valide\033[0m")
        print("Configuration enregistrée dans le dictionnaire")
        return ": Modifier"
